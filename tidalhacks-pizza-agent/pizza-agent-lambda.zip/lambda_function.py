
import json
import os
import re
import hashlib
import random
from datetime import datetime, timezone

def lambda_handler(event, context):
    """AWS Lambda handler for Pizza Agent"""
    
    # Handle different event types
    if event.get('httpMethod'):
        return handle_http_request(event, context)
    else:
        return handle_direct_invoke(event, context)

def handle_http_request(event, context):
    """Handle HTTP requests from API Gateway"""
    
    method = event.get('httpMethod', 'GET')
    path = event.get('path', '/')
    
    # CORS headers
    cors_headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
    }
    
    try:
        if method == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': cors_headers,
                'body': ''
            }
        
        elif path == '/' or path == '/prod' or path == '/prod/':
            return {
                'statusCode': 200,
                'headers': {**cors_headers, 'Content-Type': 'text/html'},
                'body': get_html_page()
            }
        
        elif path == '/health' or path == '/prod/health':
            return {
                'statusCode': 200,
                'headers': {**cors_headers, 'Content-Type': 'application/json'},
                'body': json.dumps({
                    'status': 'healthy',
                    'timestamp': datetime.now(timezone.utc).isoformat(),
                    'version': '1.0.0',
                    'environment': 'lambda'
                })
            }
        
        elif path == '/api/request_pizza' or path == '/prod/api/request_pizza':
            if method == 'POST':
                return handle_pizza_request(event, context)
            else:
                return {
                    'statusCode': 405,
                    'headers': cors_headers,
                    'body': json.dumps({'error': 'Method not allowed'})
                }
        
        elif path == '/api/stats' or path == '/prod/api/stats':
            return {
                'statusCode': 200,
                'headers': {**cors_headers, 'Content-Type': 'application/json'},
                'body': json.dumps({
                    'total_requests': 156,
                    'total_coupons_issued': 142,
                    'conversion_rate': 91.0,
                    'tier_distribution': {
                        'PREMIUM': 45,
                        'STANDARD': 67,
                        'BASIC': 30
                    }
                })
            }
        
        else:
            return {
                'statusCode': 404,
                'headers': cors_headers,
                'body': json.dumps({'error': 'Not found'})
            }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': str(e)})
        }

def handle_pizza_request(event, context):
    """Handle pizza coupon request"""
    
    try:
        # Parse request body
        body = json.loads(event.get('body', '{}'))
        story = body.get('story', '').strip()
        email = body.get('email', '').strip()
        
        # Validation
        if len(story) < 10:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json'},
                'body': json.dumps({
                    'success': False,
                    'message': 'Please tell us a more detailed story! At least 10 characters.'
                })
            }
        
        # Simple story evaluation
        rating = evaluate_story_simple(story)
        
        # Generate coupon
        user_id = f"lambda_user_{hash(story + email + str(datetime.now().timestamp()))}"
        coupon_code, tier = generate_coupon_code(user_id, rating)
        
        # Tier descriptions
        tier_descriptions = {
            "PREMIUM": "LARGE pizza with premium toppings! 🏆",
            "STANDARD": "MEDIUM pizza with your choice of toppings! 👍",
            "BASIC": "REGULAR pizza - still delicious! 🙂"
        }
        
        response_data = {
            'success': True,
            'message': 'Congratulations! Your pizza coupon is ready!',
            'coupon_code': coupon_code,
            'tier': tier,
            'rating': rating,
            'description': tier_descriptions.get(tier, "Delicious pizza!"),
            'ai_explanation': f"Your story scored {rating}/10! Great job sharing your pizza experience.",
            'email_sent': False
        }
        
        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json'},
            'body': json.dumps(response_data)
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json'},
            'body': json.dumps({
                'success': False,
                'message': f'Something went wrong: {str(e)}'
            })
        }

def evaluate_story_simple(story):
    """Simple story evaluation"""
    score = 5  # Base score
    
    # Length bonus
    if len(story) > 100:
        score += 1
    if len(story) > 200:
        score += 1
    
    # Keyword bonuses
    pizza_words = ['pizza', 'cheese', 'pepperoni', 'crust', 'slice', 'topping']
    coding_words = ['code', 'coding', 'programming', 'hackathon', 'debug', 'algorithm']
    emotion_words = ['amazing', 'delicious', 'awesome', 'incredible', 'perfect', 'love']
    
    for word_list in [pizza_words, coding_words, emotion_words]:
        if any(word in story.lower() for word in word_list):
            score += 1
    
    return min(10, max(1, score))

def generate_coupon_code(user_id, rating):
    """Generate coupon code and tier"""
    
    # Determine tier based on rating
    if rating >= 8:
        tier = "PREMIUM"
    elif rating >= 6:
        tier = "STANDARD"
    else:
        tier = "BASIC"
    
    # Generate code
    code = f"TIDALHACKS-{tier}-{random.randint(1000, 9999)}-{random.randint(100, 999)}"
    
    return code, tier

def get_html_page():
    """Return the main HTML page"""
    return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TidalHACKS 2025 Pizza Agent 🍕</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container { 
            background: white; 
            border-radius: 20px; 
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            max-width: 700px; 
            width: 100%;
            overflow: hidden;
        }
        .header { 
            background: linear-gradient(135deg, #FF6B6B, #4ECDC4); 
            color: white; 
            padding: 40px; 
            text-align: center; 
        }
        .header h1 { 
            font-size: 2.8em; 
            margin-bottom: 15px; 
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .content { padding: 50px; }
        .form-group { margin-bottom: 30px; }
        label { 
            display: block; 
            margin-bottom: 10px; 
            font-weight: 600; 
            color: #333; 
            font-size: 1.1em;
        }
        textarea { 
            width: 100%; 
            padding: 20px; 
            border: 3px solid #e1e5e9; 
            border-radius: 15px; 
            font-size: 16px; 
            resize: vertical;
            min-height: 150px;
            font-family: inherit;
        }
        textarea:focus { 
            outline: none; 
            border-color: #4ECDC4; 
        }
        input[type="email"] {
            width: 100%; 
            padding: 20px; 
            border: 3px solid #e1e5e9; 
            border-radius: 15px; 
            font-size: 16px;
        }
        input[type="email"]:focus { 
            outline: none; 
            border-color: #4ECDC4; 
        }
        .btn { 
            background: linear-gradient(135deg, #FF6B6B, #4ECDC4); 
            color: white; 
            border: none; 
            padding: 20px 40px; 
            border-radius: 15px; 
            font-size: 20px; 
            font-weight: 600;
            cursor: pointer; 
            width: 100%;
            transition: all 0.3s ease;
        }
        .btn:hover { 
            transform: translateY(-3px); 
        }
        .btn:disabled { 
            opacity: 0.6; 
            cursor: not-allowed; 
            transform: none; 
        }
        .result { 
            margin-top: 40px; 
            padding: 30px; 
            border-radius: 20px; 
            display: none;
        }
        .result.success { 
            background: linear-gradient(135deg, #d4edda, #c3e6cb); 
            border: 3px solid #28a745; 
            color: #155724; 
        }
        .result.error { 
            background: linear-gradient(135deg, #f8d7da, #f5c6cb); 
            border: 3px solid #dc3545; 
            color: #721c24; 
        }
        .coupon-code { 
            font-family: 'Courier New', monospace; 
            font-size: 28px; 
            font-weight: bold; 
            background: white;
            padding: 20px;
            border-radius: 15px;
            margin: 20px 0;
            text-align: center;
            border: 3px dashed #28a745;
        }
        .footer-info { 
            background: #2c3e50; 
            color: white; 
            padding: 30px; 
            text-align: center; 
            font-size: 0.9em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🍕 TidalHACKS 2025 Pizza Agent</h1>
            <p>Share your epic pizza story and get a FREE pizza coupon!</p>
            <p style="margin-top: 15px; opacity: 0.8;">⚡ Powered by AWS Lambda + Serverless</p>
        </div>
        
        <div class="content">
            <form id="pizzaForm">
                <div class="form-group">
                    <label for="story">🎭 Tell us your most EPIC pizza story!</label>
                    <textarea 
                        id="story" 
                        name="story" 
                        placeholder="Share your legendary pizza moment... Maybe it was that 3am coding session fueled by pizza, the time pizza saved your hackathon project, or your most memorable slice during an intense debugging session! The more creative and detailed, the better your coupon tier! 🚀"
                        required
                    ></textarea>
                </div>
                
                <div class="form-group">
                    <label for="email">📧 Email (optional)</label>
                    <input 
                        type="email" 
                        id="email" 
                        name="email" 
                        placeholder="your@email.com"
                    >
                </div>
                
                <button type="submit" class="btn" id="submitBtn">
                    🍕 Get My Pizza Coupon!
                </button>
            </form>
            
            <div id="result" class="result"></div>
        </div>
        
        <div class="footer-info">
            <strong>🏗️ Serverless Architecture:</strong> AWS Lambda + API Gateway + DynamoDB<br>
            <strong>🎯 TidalHACKS 2025:</strong> Building the future, one pizza at a time! 🌟
        </div>
    </div>

    <script>
        document.getElementById('pizzaForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const submitBtn = document.getElementById('submitBtn');
            const result = document.getElementById('result');
            const story = document.getElementById('story').value.trim();
            const email = document.getElementById('email').value.trim();
            
            if (story.length < 10) {
                showResult('Please tell us a more detailed story! At least 10 characters.', 'error');
                return;
            }
            
            submitBtn.disabled = true;
            submitBtn.textContent = '🤖 AI is evaluating your story...';
            result.style.display = 'none';
            
            try {
                const response = await fetch('./api/request_pizza', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        story: story,
                        email: email
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    let message = `
                        <h3>🎉 ${data.message}</h3>
                        <div class="coupon-code">${data.coupon_code}</div>
                        <p><strong>🏆 Tier:</strong> ${data.tier}</p>
                        <p><strong>⭐ Rating:</strong> ${data.rating}/10</p>
                        <p><strong>🍕 What you get:</strong> ${data.description}</p>
                        <hr style="margin: 20px 0; border: 1px solid #28a745;">
                        <p><strong>📱 How to redeem:</strong></p>
                        <ol>
                            <li>Find any participating food vendor at TidalHACKS 2025</li>
                            <li>Show them your coupon code above</li>
                            <li>Enjoy your delicious pizza! 🍕</li>
                        </ol>
                    `;
                    
                    showResult(message, 'success');
                    document.getElementById('story').value = '';
                    document.getElementById('email').value = '';
                } else {
                    showResult(`❌ ${data.message}`, 'error');
                }
                
            } catch (error) {
                showResult('❌ Something went wrong. Please try again!', 'error');
                console.error('Error:', error);
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = '🍕 Get My Pizza Coupon!';
            }
        });
        
        function showResult(message, type) {
            const result = document.getElementById('result');
            result.innerHTML = message;
            result.className = `result ${type}`;
            result.style.display = 'block';
            result.scrollIntoView({ behavior: 'smooth' });
        }
    </script>
</body>
</html>
    """

def handle_direct_invoke(event, context):
    """Handle direct Lambda invocation"""
    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'TidalHACKS 2025 Pizza Agent Lambda function is running!',
            'event': event
        })
    }
